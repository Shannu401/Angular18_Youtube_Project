export interface IRole {
    roleId : number,
    role : string
}